
export default new Map([
["src/content/work/assistive-technology-design.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fcontent%2Fwork%2Fassistive-technology-design.mdx&astroContentModuleFlag=true")],
["src/content/work/data-storytelling-r.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fcontent%2Fwork%2Fdata-storytelling-r.mdx&astroContentModuleFlag=true")],
["src/content/work/dye-durham-product.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fcontent%2Fwork%2Fdye-durham-product.mdx&astroContentModuleFlag=true")],
["src/content/work/innovation-hub-design-research.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fcontent%2Fwork%2Finnovation-hub-design-research.mdx&astroContentModuleFlag=true")],
["src/content/work/job-search-automation.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fcontent%2Fwork%2Fjob-search-automation.mdx&astroContentModuleFlag=true")],
["src/content/work/kronos-forecasting-research.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fcontent%2Fwork%2Fkronos-forecasting-research.mdx&astroContentModuleFlag=true")],
["src/content/work/personal-ai-os.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fcontent%2Fwork%2Fpersonal-ai-os.mdx&astroContentModuleFlag=true")],
["src/content/work/smart-commute-research.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fcontent%2Fwork%2Fsmart-commute-research.mdx&astroContentModuleFlag=true")],
["src/content/work/smartsyllabus.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fcontent%2Fwork%2Fsmartsyllabus.mdx&astroContentModuleFlag=true")],
["src/content/work/sunlife-digital-transformation.mdx", () => import("astro:content-layer-deferred-module?astro%3Acontent-layer-deferred-module=&fileName=src%2Fcontent%2Fwork%2Fsunlife-digital-transformation.mdx&astroContentModuleFlag=true")]]);
		